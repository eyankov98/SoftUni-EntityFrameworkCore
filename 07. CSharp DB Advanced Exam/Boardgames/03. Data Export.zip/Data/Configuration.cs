﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-I00ATHT;Database=Boardgames;Integrated Security=True;Encrypt=False;TrustServerCertificate=True";
    }
}
