﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-I00ATHT;Database=ProductShop;Integrated Security=True;Encrypt=False;TrustServerCertificate=True";
    }
}
