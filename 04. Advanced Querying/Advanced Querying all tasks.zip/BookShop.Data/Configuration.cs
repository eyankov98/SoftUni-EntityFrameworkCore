﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-I00ATHT;Database=BookShop;Integrated Security=True;";
    }
}
