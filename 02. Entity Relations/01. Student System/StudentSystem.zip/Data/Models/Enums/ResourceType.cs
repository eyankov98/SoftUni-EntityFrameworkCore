﻿namespace StudentSystem.Data.Models.Enums;

public enum ResourceType
{
    Video,
    Presentation,
    Document,
    Other
}
