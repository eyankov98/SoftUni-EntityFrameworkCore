﻿namespace StudentSystem.Data.Models.Enums;

public enum ContentType
{
    Application,
    Pdf,
    Zip
}
