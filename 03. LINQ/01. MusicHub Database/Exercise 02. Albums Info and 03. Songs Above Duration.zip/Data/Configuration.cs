﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-I00ATHT;Database=MusicHub;Integrated Security=True;TrustServerCertificate=True";
    }
}
